import React from "react";
import TodoList from './TodoList';
import TodoStore from './TodoStore';

const App = () => {return (<TodoList />);}

export default App;

import React from "react";
import "./styles/TodoList.css";

const TodoList = () => {<h1 id="title">MobX</h1>};

export default TodoList;